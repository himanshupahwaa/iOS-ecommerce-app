//
//  SweaterShopAppApp.swift
//  SweaterShopApp
//
//  Created by Stephanie Diep on 2021-12-23.
//

import SwiftUI

@main
struct SweaterShopAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
